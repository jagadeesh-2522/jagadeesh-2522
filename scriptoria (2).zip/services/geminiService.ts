import { GoogleGenAI, Type, Schema } from "@google/genai";
import { ProjectDraft, ProjectMode, GeneratedContent } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

// Schema for structured output
const characterSchema: Schema = {
  type: Type.OBJECT,
  properties: {
    name: { type: Type.STRING },
    role: { type: Type.STRING, enum: ['Protagonist', 'Antagonist', 'Support'] },
    physicalTraits: { type: Type.STRING, description: "Height, build, age range, appearance style" },
    personality: { type: Type.STRING },
    motivation: { type: Type.STRING, description: "Inner conflicts and motivations" },
    narrativePurpose: { type: Type.STRING }
  },
  required: ["name", "role", "physicalTraits", "personality", "motivation", "narrativePurpose"]
};

const responseSchema: Schema = {
  type: Type.OBJECT,
  properties: {
    title: { type: Type.STRING },
    synopsis: { type: Type.STRING },
    content: { type: Type.STRING, description: "The full story prose or formatted screenplay text." },
    characters: {
      type: Type.ARRAY,
      items: characterSchema
    }
  },
  required: ["title", "synopsis", "content", "characters"]
};

export const generateStoryOrScript = async (draft: ProjectDraft): Promise<GeneratedContent> => {
  const isScript = draft.mode === ProjectMode.SCRIPT;
  
  const systemInstruction = `You are Scriptoria, a world-class cinematic writing AI. 
  Your goal is to write a ${draft.duration} ${draft.type} in the genre of ${draft.genre}.
  
  Tone: ${draft.tone}
  Theme: ${draft.theme}
  Additional Notes: ${draft.additionalInfo}

  FORMATTING RULES:
  ${isScript 
    ? `Write in strict INDUSTRY STANDARD SCREENPLAY FORMAT. 
       - Use INT./EXT. for scene headings.
       - Include specific BGM (Background Music) cues where emotionally appropriate (e.g., [SOUND: Melancholic piano fades in]).
       - Focus on visual action and realistic dialogue.` 
    : `Write in a PROSE-DRIVEN NARRATIVE format (like a novel or short story). 
       - Focus on sensory details, internal monologue, and atmospheric descriptions.
       - Use varied paragraph structure.`}
  
  Ensure the content is high quality, creative, and strictly follows the requested tone.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: "Generate the creative work based on the system instructions.",
      config: {
        systemInstruction: systemInstruction,
        responseMimeType: "application/json",
        responseSchema: responseSchema,
        temperature: 0.8, // Slightly higher for creativity
      }
    });

    if (!response.text) {
        throw new Error("No text generated");
    }

    const data = JSON.parse(response.text) as GeneratedContent;
    return data;

  } catch (error) {
    console.error("Gemini Generation Error:", error);
    throw error;
  }
};

export const generateCharacterImage = async (characterDescription: string): Promise<string | undefined> => {
  try {
    // Using generateContent for image generation model as per documentation for nano banana models
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: `Cinematic concept art, character portrait, detailed, 8k, professional lighting. Character description: ${characterDescription}`,
    });

    // Extract image from response parts
    for (const part of response.candidates?.[0]?.content?.parts || []) {
      if (part.inlineData) {
        return `data:image/png;base64,${part.inlineData.data}`;
      }
    }
    return undefined;
  } catch (error) {
    console.error("Image Gen Error:", error);
    return undefined;
  }
};

export const generatePosterImage = async (theme: string, genre: string, title: string): Promise<string | undefined> => {
    try {
      const prompt = `Movie poster for a ${genre} film titled "${title}". Theme: ${theme}. Cinematic composition, typography, high quality, award winning design.`;
      
      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash-image',
        contents: prompt,
      });
  
      for (const part of response.candidates?.[0]?.content?.parts || []) {
        if (part.inlineData) {
          return `data:image/png;base64,${part.inlineData.data}`;
        }
      }
      return undefined;
    } catch (error) {
      console.error("Poster Gen Error:", error);
      return undefined;
    }
  };