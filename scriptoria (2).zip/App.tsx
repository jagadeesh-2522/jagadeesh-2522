import React, { useState, useEffect, useRef } from 'react';
import Logo from './components/Logo';
import CharacterCard from './components/CharacterCard';
import { generateStoryOrScript, generateCharacterImage, generatePosterImage } from './services/geminiService';
import { Screen, ProjectType, ProjectMode, UserProfile, ProjectDraft, GeneratedContent } from './types';
import { ArrowRight, ChevronLeft, Loader2, Sparkles, BookOpen, FileText, Layout, Play, Download, Image as ImageIcon } from 'lucide-react';

// -- Mock Constants --
const GENRES = ['Drama', 'Sci-Fi', 'Comedy', 'Thriller', 'Romance', 'Horror', 'Mystery', 'Fantasy'];
const DURATIONS = ['1-5 Minutes', '5-15 Minutes', '30 Minutes', '60 Minutes', '90+ Minutes'];

// -- Main Component --
export default function App() {
  const [screen, setScreen] = useState<Screen>(Screen.LANDING);
  const [user, setUser] = useState<UserProfile | null>(null);
  const [draft, setDraft] = useState<ProjectDraft>({
    type: null,
    genre: '',
    duration: '',
    mode: null,
    theme: '',
    tone: '',
    additionalInfo: ''
  });
  const [result, setResult] = useState<GeneratedContent | null>(null);
  const [loadingMessage, setLoadingMessage] = useState("Initializing creative engine...");
  const [activeTab, setActiveTab] = useState<'content' | 'characters' | 'visuals'>('content');
  const [generatingImgId, setGeneratingImgId] = useState<number | null>(null);
  const [generatingPosters, setGeneratingPosters] = useState(false);

  // -- Handlers --

  const handleAuth = (e: React.FormEvent) => {
    e.preventDefault();
    setScreen(Screen.ONBOARDING);
  };

  const handleOnboarding = (e: React.FormEvent) => {
    e.preventDefault();
    const formData = new FormData(e.target as HTMLFormElement);
    setUser({
      email: 'user@example.com', // Mock
      name: formData.get('name') as string,
      dob: formData.get('dob') as string,
      country: formData.get('country') as string,
    });
    setScreen(Screen.DASHBOARD);
  };

  const startNewProject = () => {
    setDraft({ type: null, genre: '', duration: '', mode: null, theme: '', tone: '', additionalInfo: '' });
    setScreen(Screen.WIZARD_TYPE);
  };

  const handleGenerate = async () => {
    setScreen(Screen.LOADING);
    const messages = [
      "Analyzing narrative structure...",
      "Developing character arcs...",
      "Setting the scene...",
      "Drafting dialogue...",
      "Polishing final output..."
    ];
    let msgIdx = 0;
    const interval = setInterval(() => {
        setLoadingMessage(messages[msgIdx % messages.length]);
        msgIdx++;
    }, 2500);

    try {
      const content = await generateStoryOrScript(draft);
      setResult(content);
      clearInterval(interval);
      setScreen(Screen.RESULT);
    } catch (e) {
      console.error(e);
      alert("Something went wrong with the AI generation. Please check your API key.");
      setScreen(Screen.WIZARD_DETAILS);
    }
  };

  const handleGenerateCharImage = async (index: number) => {
    if (!result) return;
    setGeneratingImgId(index);
    const char = result.characters[index];
    const prompt = `${char.physicalTraits}. ${char.appearance_style || 'Cinematic style'}. Role: ${char.role}`;
    
    const url = await generateCharacterImage(prompt);
    
    if (url) {
        const newChars = [...result.characters];
        newChars[index] = { ...char, imageUrl: url };
        setResult({ ...result, characters: newChars });
    }
    setGeneratingImgId(null);
  };

  const handleGeneratePosters = async () => {
    if (!result) return;
    setGeneratingPosters(true);
    const posters: string[] = [];
    
    // Generate 3 variations
    for (let i = 0; i < 3; i++) {
        const url = await generatePosterImage(draft.theme, draft.genre, result.title);
        if (url) posters.push(url);
    }

    setResult({ ...result, posters });
    setGeneratingPosters(false);
  };

  // -- Render Helpers --

  const renderLanding = () => (
    <div className="min-h-screen flex flex-col items-center justify-center p-8 bg-gradient-to-br from-scriptoria-light to-white text-center">
      <div className="fade-in mb-8">
        <Logo size="xl" />
        <p className="text-xl text-gray-600 mt-4 font-light tracking-wide">Script it right with Scriptoria.</p>
      </div>
      <button 
        onClick={() => setScreen(Screen.AUTH)}
        className="px-8 py-4 bg-scriptoria-dark text-white rounded-full text-lg font-semibold shadow-xl hover:shadow-2xl hover:scale-105 transition-all duration-300 flex items-center gap-3 fade-in"
        style={{ animationDelay: '0.3s' }}
      >
        Start Creating <ArrowRight size={20} />
      </button>
    </div>
  );

  const renderAuth = () => (
    <div className="min-h-screen flex items-center justify-center bg-scriptoria-light">
      <div className="bg-white p-10 rounded-2xl shadow-xl w-full max-w-md slide-up">
        <Logo size="sm" className="mb-6" />
        <h2 className="text-2xl font-serif font-bold text-gray-800 mb-6 text-center">Welcome Back</h2>
        <form onSubmit={handleAuth} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Email Address</label>
            <input type="email" required className="w-full p-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-scriptoria-medium outline-none transition" placeholder="writer@scriptoria.ai" />
          </div>
          <button type="submit" className="w-full py-3 bg-scriptoria-dark text-white rounded-lg font-semibold hover:bg-opacity-90 transition">
            Continue with Email
          </button>
        </form>
      </div>
    </div>
  );

  const renderOnboarding = () => (
    <div className="min-h-screen flex items-center justify-center bg-scriptoria-light">
      <div className="bg-white p-10 rounded-2xl shadow-xl w-full max-w-md slide-up">
        <div className="mb-6 text-center">
             <h2 className="text-2xl font-serif font-bold text-gray-800">Tell us about you</h2>
             <p className="text-sm text-gray-500">Let's personalize your studio.</p>
        </div>
        <form onSubmit={handleOnboarding} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Full Name</label>
            <input name="name" type="text" required className="w-full p-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-scriptoria-medium outline-none transition" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Date of Birth</label>
            <input name="dob" type="date" required className="w-full p-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-scriptoria-medium outline-none transition" />
          </div>
          <div>
             <label className="block text-sm font-medium text-gray-700 mb-1">Country</label>
             <select name="country" className="w-full p-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-scriptoria-medium outline-none transition">
                 <option>United States</option>
                 <option>United Kingdom</option>
                 <option>Canada</option>
                 <option>France</option>
                 <option>Germany</option>
                 <option>Japan</option>
                 <option>India</option>
                 <option>Other</option>
             </select>
          </div>
          <button type="submit" className="w-full py-3 bg-scriptoria-dark text-white rounded-lg font-semibold hover:bg-opacity-90 transition mt-4">
            Enter Studio
          </button>
        </form>
      </div>
    </div>
  );

  const renderDashboard = () => (
    <div className="min-h-screen bg-white flex">
      {/* Sidebar */}
      <div className="w-64 bg-scriptoria-light border-r border-gray-100 hidden md:flex flex-col p-6">
        <Logo size="md" className="mb-10 self-start" />
        <nav className="space-y-2 flex-1">
          <button className="w-full text-left px-4 py-3 bg-white rounded-xl text-scriptoria-dark font-semibold shadow-sm flex items-center gap-3">
             <Layout size={18} /> Dashboard
          </button>
          <button className="w-full text-left px-4 py-3 text-gray-600 hover:bg-white/50 rounded-xl transition flex items-center gap-3">
             <BookOpen size={18} /> Library
          </button>
        </nav>
        <div className="flex items-center gap-3 mt-auto p-4 bg-white/50 rounded-xl">
            <div className="w-10 h-10 rounded-full bg-scriptoria-dark flex items-center justify-center text-white font-bold">
                {user?.name.charAt(0)}
            </div>
            <div className="overflow-hidden">
                <p className="text-sm font-bold text-gray-800 truncate">{user?.name}</p>
                <p className="text-xs text-gray-500 truncate">{user?.country}</p>
            </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 p-8 overflow-y-auto">
        <div className="flex justify-between items-center mb-10">
            <h2 className="text-3xl font-serif font-bold text-gray-800">Your Projects</h2>
            <button 
                onClick={startNewProject}
                className="px-6 py-3 bg-scriptoria-dark text-white rounded-full font-semibold shadow-lg hover:shadow-xl hover:scale-105 transition flex items-center gap-2"
            >
                <Sparkles size={18} /> Create New
            </button>
        </div>

        {/* Empty State / Templates */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
             <div onClick={startNewProject} className="border-2 border-dashed border-gray-300 rounded-2xl p-8 flex flex-col items-center justify-center text-gray-400 hover:border-scriptoria-medium hover:text-scriptoria-dark hover:bg-scriptoria-light/10 transition cursor-pointer h-64">
                <div className="w-16 h-16 rounded-full bg-gray-100 flex items-center justify-center mb-4">
                    <Sparkles size={24} />
                </div>
                <span className="font-medium">Start Blank Project</span>
             </div>
             {/* Mock Existing Projects */}
             <div className="bg-white border border-gray-100 rounded-2xl p-6 shadow-sm hover:shadow-md transition h-64 flex flex-col relative group overflow-hidden">
                <div className="absolute top-0 left-0 w-2 h-full bg-scriptoria-medium"></div>
                <span className="text-xs font-bold text-scriptoria-dark uppercase tracking-wider mb-2">Short Film</span>
                <h3 className="text-xl font-serif font-bold mb-2">The Midnight Train</h3>
                <p className="text-sm text-gray-500 line-clamp-3">A mystery thriller about a passenger who disappears from a moving train...</p>
                <div className="mt-auto pt-4 border-t border-gray-50 flex justify-between items-center text-xs text-gray-400">
                    <span>Edited 2 days ago</span>
                </div>
             </div>
        </div>
      </div>
    </div>
  );

  const renderWizard = () => {
    const isLastStep = screen === Screen.WIZARD_DETAILS;

    const progress = () => {
        switch(screen) {
            case Screen.WIZARD_TYPE: return '25%';
            case Screen.WIZARD_GENRE: return '50%';
            case Screen.WIZARD_MODE: return '75%';
            case Screen.WIZARD_DETAILS: return '100%';
            default: return '0%';
        }
    };

    return (
        <div className="min-h-screen bg-scriptoria-light flex flex-col items-center pt-20 px-6">
            <div className="w-full max-w-3xl">
                <div className="w-full bg-gray-200 h-1.5 rounded-full mb-12 overflow-hidden">
                    <div className="h-full bg-scriptoria-dark transition-all duration-500" style={{ width: progress() }}></div>
                </div>

                <div className="bg-white rounded-3xl shadow-xl p-10 md:p-14 min-h-[500px] flex flex-col relative fade-in">
                    <button 
                        onClick={() => {
                            if (screen === Screen.WIZARD_TYPE) setScreen(Screen.DASHBOARD);
                            if (screen === Screen.WIZARD_GENRE) setScreen(Screen.WIZARD_TYPE);
                            if (screen === Screen.WIZARD_MODE) setScreen(Screen.WIZARD_GENRE);
                            if (screen === Screen.WIZARD_DETAILS) setScreen(Screen.WIZARD_MODE);
                        }}
                        className="absolute top-8 left-8 text-gray-400 hover:text-gray-800 transition"
                    >
                        <ChevronLeft size={24} />
                    </button>

                    <div className="flex-1 flex flex-col justify-center items-center text-center">
                        
                        {screen === Screen.WIZARD_TYPE && (
                            <div className="space-y-8 w-full animate-in fade-in slide-in-from-bottom-4">
                                <h2 className="text-3xl font-serif font-bold text-gray-800">What format are we creating?</h2>
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    {Object.values(ProjectType).map((t) => (
                                        <button 
                                            key={t}
                                            onClick={() => { setDraft({...draft, type: t}); setScreen(Screen.WIZARD_GENRE); }}
                                            className="p-6 rounded-xl border-2 border-gray-100 hover:border-scriptoria-medium hover:bg-scriptoria-light/20 transition text-lg font-medium text-gray-700 hover:text-scriptoria-dark text-left group"
                                        >
                                            {t}
                                        </button>
                                    ))}
                                </div>
                            </div>
                        )}

                        {screen === Screen.WIZARD_GENRE && (
                             <div className="space-y-8 w-full animate-in fade-in slide-in-from-bottom-4">
                                <h2 className="text-3xl font-serif font-bold text-gray-800">Choose your genre & duration</h2>
                                <div className="space-y-6 max-w-lg mx-auto">
                                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                                        {GENRES.map(g => (
                                            <button 
                                                key={g} 
                                                onClick={() => setDraft({...draft, genre: g})}
                                                className={`py-2 px-4 rounded-full text-sm border transition ${draft.genre === g ? 'bg-scriptoria-dark text-white border-scriptoria-dark' : 'border-gray-200 text-gray-600 hover:border-scriptoria-medium'}`}
                                            >
                                                {g}
                                            </button>
                                        ))}
                                    </div>
                                    <div className="pt-4 border-t border-gray-100">
                                         <p className="text-sm font-bold text-gray-500 mb-3 uppercase tracking-wider">Duration</p>
                                         <select 
                                            onChange={(e) => setDraft({...draft, duration: e.target.value})}
                                            className="w-full p-4 bg-gray-50 rounded-xl outline-none focus:ring-2 focus:ring-scriptoria-medium"
                                            value={draft.duration}
                                         >
                                             <option value="">Select Target Runtime</option>
                                             {DURATIONS.map(d => <option key={d} value={d}>{d}</option>)}
                                         </select>
                                    </div>
                                    <button 
                                        disabled={!draft.genre || !draft.duration}
                                        onClick={() => setScreen(Screen.WIZARD_MODE)}
                                        className="w-full py-4 bg-scriptoria-dark text-white rounded-xl font-bold hover:bg-opacity-90 transition disabled:opacity-50 disabled:cursor-not-allowed"
                                    >
                                        Next Step
                                    </button>
                                </div>
                             </div>
                        )}

                        {screen === Screen.WIZARD_MODE && (
                             <div className="space-y-8 w-full animate-in fade-in slide-in-from-bottom-4">
                                <h2 className="text-3xl font-serif font-bold text-gray-800">How should it be written?</h2>
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                    <div 
                                        onClick={() => { setDraft({...draft, mode: ProjectMode.STORY}); setScreen(Screen.WIZARD_DETAILS); }}
                                        className="cursor-pointer border-2 border-transparent bg-gray-50 p-8 rounded-2xl hover:bg-scriptoria-light/30 hover:border-scriptoria-medium transition text-left group"
                                    >
                                        <div className="w-12 h-12 bg-white rounded-full shadow-sm flex items-center justify-center mb-4 text-scriptoria-dark">
                                            <BookOpen size={24} />
                                        </div>
                                        <h3 className="text-xl font-bold text-gray-800 mb-2">Story Format</h3>
                                        <p className="text-sm text-gray-500 leading-relaxed">Prose-driven narrative. Rich character descriptions, emotional depth, and novel-like reading experience.</p>
                                    </div>
                                    <div 
                                        onClick={() => { setDraft({...draft, mode: ProjectMode.SCRIPT}); setScreen(Screen.WIZARD_DETAILS); }}
                                        className="cursor-pointer border-2 border-transparent bg-gray-50 p-8 rounded-2xl hover:bg-scriptoria-light/30 hover:border-scriptoria-medium transition text-left group"
                                    >
                                        <div className="w-12 h-12 bg-white rounded-full shadow-sm flex items-center justify-center mb-4 text-scriptoria-dark">
                                            <FileText size={24} />
                                        </div>
                                        <h3 className="text-xl font-bold text-gray-800 mb-2">Script Format</h3>
                                        <p className="text-sm text-gray-500 leading-relaxed">Industry-standard screenplay formatting. Scene headings, dialogue, transitions, and BGM cues.</p>
                                    </div>
                                </div>
                             </div>
                        )}

                        {screen === Screen.WIZARD_DETAILS && (
                            <div className="space-y-6 w-full animate-in fade-in slide-in-from-bottom-4 text-left">
                                <h2 className="text-3xl font-serif font-bold text-gray-800 text-center">Final Creative Touches</h2>
                                
                                <div className="space-y-4">
                                    <div>
                                        <label className="block text-sm font-bold text-gray-700 mb-2">Central Theme / Premise</label>
                                        <input 
                                            className="w-full p-4 bg-gray-50 rounded-xl focus:ring-2 focus:ring-scriptoria-medium outline-none"
                                            placeholder="e.g., A robot learns to love in a post-apocalyptic garden."
                                            onChange={(e) => setDraft({...draft, theme: e.target.value})}
                                        />
                                    </div>
                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                        <div>
                                            <label className="block text-sm font-bold text-gray-700 mb-2">Emotional Tone</label>
                                            <input 
                                                className="w-full p-4 bg-gray-50 rounded-xl focus:ring-2 focus:ring-scriptoria-medium outline-none"
                                                placeholder="e.g., Melancholic, Hopeful"
                                                onChange={(e) => setDraft({...draft, tone: e.target.value})}
                                            />
                                        </div>
                                        <div>
                                            <label className="block text-sm font-bold text-gray-700 mb-2">Additional Elements (Optional)</label>
                                            <input 
                                                className="w-full p-4 bg-gray-50 rounded-xl focus:ring-2 focus:ring-scriptoria-medium outline-none"
                                                placeholder="Specific plot twist, setting, etc."
                                                onChange={(e) => setDraft({...draft, additionalInfo: e.target.value})}
                                            />
                                        </div>
                                    </div>
                                </div>

                                <div className="pt-6">
                                     <button 
                                        onClick={handleGenerate}
                                        disabled={!draft.theme || !draft.tone}
                                        className="w-full py-5 bg-gradient-to-r from-scriptoria-dark to-scriptoria-medium text-white rounded-xl font-bold text-lg hover:shadow-lg hover:scale-[1.01] transition-all flex items-center justify-center gap-2 disabled:opacity-50 disabled:scale-100"
                                    >
                                        <Sparkles size={20} /> Generate {draft.mode}
                                    </button>
                                </div>
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
  };

  const renderLoading = () => (
    <div className="min-h-screen bg-scriptoria-dark flex flex-col items-center justify-center text-white relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-10"></div>
        <div className="z-10 flex flex-col items-center">
            <Loader2 size={64} className="animate-spin mb-8 text-scriptoria-medium" />
            <h2 className="text-3xl font-serif font-bold mb-4 tracking-wider animate-pulse">Scriptoria AI</h2>
            <p className="text-scriptoria-light text-lg font-light italic h-8">{loadingMessage}</p>
        </div>
    </div>
  );

  const renderResult = () => {
    if (!result) return null;

    return (
        <div className="min-h-screen bg-gray-50 flex flex-col">
            {/* Header */}
            <header className="bg-white border-b border-gray-200 sticky top-0 z-20 shadow-sm">
                <div className="max-w-7xl mx-auto px-6 py-4 flex justify-between items-center">
                    <div className="flex items-center gap-4">
                        <button onClick={() => setScreen(Screen.DASHBOARD)} className="text-gray-400 hover:text-gray-800">
                            <ChevronLeft size={24} />
                        </button>
                        <div>
                             <h1 className="text-xl font-serif font-bold text-gray-800">{result.title}</h1>
                             <span className="text-xs text-gray-500 uppercase tracking-widest">{draft.type} • {draft.genre}</span>
                        </div>
                    </div>
                    <div className="flex gap-2">
                        <button className="px-4 py-2 border border-gray-200 rounded-lg text-gray-600 hover:bg-gray-50 flex items-center gap-2 text-sm font-medium">
                            <Download size={16} /> Export PDF
                        </button>
                    </div>
                </div>
                {/* Tabs */}
                <div className="max-w-7xl mx-auto px-6 flex gap-8">
                    <button 
                        onClick={() => setActiveTab('content')}
                        className={`py-3 text-sm font-bold border-b-2 transition ${activeTab === 'content' ? 'border-scriptoria-dark text-scriptoria-dark' : 'border-transparent text-gray-500 hover:text-gray-800'}`}
                    >
                        {draft.mode === ProjectMode.SCRIPT ? 'Screenplay' : 'Story'}
                    </button>
                    <button 
                        onClick={() => setActiveTab('characters')}
                        className={`py-3 text-sm font-bold border-b-2 transition ${activeTab === 'characters' ? 'border-scriptoria-dark text-scriptoria-dark' : 'border-transparent text-gray-500 hover:text-gray-800'}`}
                    >
                        Characters
                    </button>
                    <button 
                        onClick={() => setActiveTab('visuals')}
                        className={`py-3 text-sm font-bold border-b-2 transition ${activeTab === 'visuals' ? 'border-scriptoria-dark text-scriptoria-dark' : 'border-transparent text-gray-500 hover:text-gray-800'}`}
                    >
                        Visual Assets
                    </button>
                </div>
            </header>

            {/* Content Area */}
            <main className="flex-1 overflow-y-auto p-8">
                <div className="max-w-5xl mx-auto">
                    
                    {activeTab === 'content' && (
                        <div className="bg-white rounded-none shadow-lg min-h-[800px] p-12 md:p-20 relative animate-in fade-in zoom-in-95 duration-500">
                             {/* Paper texture feel */}
                             <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-gray-100 to-gray-50"></div>
                             
                             <div className="mb-12 text-center">
                                 <h1 className="font-mono underline text-3xl mb-4 font-bold uppercase">{result.title}</h1>
                                 <p className="font-mono text-sm uppercase mb-8">Written by {user?.name || 'Scriptoria AI'}</p>
                                 <div className="w-1/3 h-px bg-gray-300 mx-auto"></div>
                             </div>
                             
                             <div className={`prose max-w-none ${draft.mode === ProjectMode.SCRIPT ? 'font-mono whitespace-pre-wrap leading-relaxed' : 'font-serif text-lg leading-loose'}`}>
                                 {/* Formatting hack for screenplay to center Names if simple markdown doesn't cover it. 
                                     Ideally we parse the script content, but for this demo, we trust the AI output format. 
                                 */}
                                 {result.content}
                             </div>
                        </div>
                    )}

                    {activeTab === 'characters' && (
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 animate-in fade-in slide-in-from-bottom-4">
                            {result.characters.map((char, idx) => (
                                <CharacterCard 
                                    key={idx} 
                                    character={char} 
                                    onGenerateImage={() => handleGenerateCharImage(idx)}
                                    isGeneratingImage={generatingImgId === idx}
                                />
                            ))}
                        </div>
                    )}

                    {activeTab === 'visuals' && (
                        <div className="animate-in fade-in slide-in-from-bottom-4">
                            {!result.posters || result.posters.length === 0 ? (
                                <div className="flex flex-col items-center justify-center h-96 bg-white rounded-xl border-2 border-dashed border-gray-200">
                                    <div className="w-20 h-20 bg-scriptoria-light rounded-full flex items-center justify-center text-scriptoria-dark mb-6">
                                        <ImageIcon size={32} />
                                    </div>
                                    <h3 className="text-xl font-serif font-bold text-gray-800 mb-2">Generate Visual Assets</h3>
                                    <p className="text-gray-500 max-w-md text-center mb-8">Create cinematic posters based on your story's theme and generated characters.</p>
                                    <button 
                                        onClick={handleGeneratePosters}
                                        disabled={generatingPosters}
                                        className="px-8 py-3 bg-scriptoria-dark text-white rounded-full font-bold shadow-lg hover:shadow-xl hover:scale-105 transition flex items-center gap-2 disabled:opacity-50"
                                    >
                                        {generatingPosters ? <Loader2 className="animate-spin"/> : <Sparkles size={18} />}
                                        {generatingPosters ? 'Designing...' : 'Generate Posters'}
                                    </button>
                                </div>
                            ) : (
                                <div>
                                    <h3 className="text-2xl font-serif font-bold text-gray-800 mb-8">Marketing Assets</h3>
                                    <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                                        {result.posters.map((url, i) => (
                                            <div key={i} className="group relative aspect-[2/3] bg-gray-900 rounded-xl overflow-hidden shadow-2xl hover:scale-[1.02] transition duration-500">
                                                <img src={url} alt={`Poster ${i}`} className="w-full h-full object-cover opacity-90 group-hover:opacity-100 transition" />
                                                <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent opacity-0 group-hover:opacity-100 transition duration-300 flex items-end p-6">
                                                    <button className="w-full py-2 bg-white text-black font-bold text-sm rounded hover:bg-gray-200">Download</button>
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            )}
                        </div>
                    )}
                </div>
            </main>
        </div>
    );
  };

  return (
    <div className="font-sans text-gray-900">
      {screen === Screen.LANDING && renderLanding()}
      {screen === Screen.AUTH && renderAuth()}
      {screen === Screen.ONBOARDING && renderOnboarding()}
      {screen === Screen.DASHBOARD && renderDashboard()}
      {screen === Screen.WIZARD_TYPE && renderWizard()}
      {screen === Screen.WIZARD_GENRE && renderWizard()}
      {screen === Screen.WIZARD_MODE && renderWizard()}
      {screen === Screen.WIZARD_DETAILS && renderWizard()}
      {screen === Screen.LOADING && renderLoading()}
      {screen === Screen.RESULT && renderResult()}
    </div>
  );
}