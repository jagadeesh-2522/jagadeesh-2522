export enum Screen {
  LANDING = 'LANDING',
  AUTH = 'AUTH',
  ONBOARDING = 'ONBOARDING',
  DASHBOARD = 'DASHBOARD',
  WIZARD_TYPE = 'WIZARD_TYPE',
  WIZARD_GENRE = 'WIZARD_GENRE',
  WIZARD_MODE = 'WIZARD_MODE',
  WIZARD_DETAILS = 'WIZARD_DETAILS',
  LOADING = 'LOADING',
  RESULT = 'RESULT',
}

export enum ProjectType {
  SHORT_FILM = 'Short Film',
  FEATURE_FILM = 'Feature Film',
  WEB_SERIES = 'Web Series',
  EXPERIMENTAL = 'Experimental / Indie',
}

export enum ProjectMode {
  STORY = 'Story',
  SCRIPT = 'Script',
}

export interface Character {
  name: string;
  role: 'Protagonist' | 'Antagonist' | 'Support';
  physicalTraits: string;
  personality: string;
  motivation: string;
  narrativePurpose: string;
  imageUrl?: string; // Generated later
}

export interface GeneratedContent {
  title: string;
  synopsis: string;
  content: string; // The full script or story text
  characters: Character[];
  posters?: string[];
}

export interface UserProfile {
  email: string;
  name: string;
  dob: string;
  country: string;
}

export interface ProjectDraft {
  type: ProjectType | null;
  genre: string;
  duration: string;
  mode: ProjectMode | null;
  theme: string;
  tone: string;
  additionalInfo: string;
}