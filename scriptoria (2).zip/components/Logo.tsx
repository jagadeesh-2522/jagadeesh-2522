import React from 'react';
import { Feather } from 'lucide-react';

interface LogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
}

const Logo: React.FC<LogoProps> = ({ size = 'md', className = '' }) => {
  const dim = {
    sm: 24,
    md: 48,
    lg: 64,
    xl: 96,
  }[size];

  const fontSize = {
    sm: 'text-lg',
    md: 'text-2xl',
    lg: 'text-4xl',
    xl: 'text-6xl',
  }[size];

  return (
    <div className={`flex flex-col items-center justify-center ${className}`}>
      <div className={`bg-scriptoria-dark text-white rounded-full p-3 mb-2 flex items-center justify-center shadow-lg transform transition-transform duration-500 hover:scale-105`}>
         <Feather size={dim / 1.5} strokeWidth={1.5} />
      </div>
      <h1 className={`font-serif font-bold text-scriptoria-dark tracking-wide ${fontSize}`}>
        Scriptoria
      </h1>
    </div>
  );
};

export default Logo;