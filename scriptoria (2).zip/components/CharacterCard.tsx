import React from 'react';
import { Character } from '../types';
import { User, Sparkles } from 'lucide-react';

interface CharacterCardProps {
  character: Character;
  onGenerateImage?: () => void;
  isGeneratingImage?: boolean;
}

const CharacterCard: React.FC<CharacterCardProps> = ({ character, onGenerateImage, isGeneratingImage }) => {
  return (
    <div className="bg-white rounded-xl shadow-sm border border-scriptoria-light overflow-hidden flex flex-col h-full transform transition hover:-translate-y-1 hover:shadow-md duration-300">
      <div className="h-64 bg-gray-100 relative overflow-hidden group">
        {character.imageUrl ? (
          <img 
            src={character.imageUrl} 
            alt={character.name} 
            className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" 
          />
        ) : (
          <div className="w-full h-full flex flex-col items-center justify-center text-scriptoria-medium bg-scriptoria-light/30">
            <User size={48} className="mb-2 opacity-50" />
            <span className="text-sm font-medium">No Visual Reference</span>
            {onGenerateImage && (
                <button 
                    onClick={onGenerateImage}
                    disabled={isGeneratingImage}
                    className="mt-4 px-4 py-2 bg-scriptoria-dark text-white text-xs rounded-full flex items-center gap-2 hover:bg-opacity-90 transition disabled:opacity-50"
                >
                   {isGeneratingImage ? 'Painting...' : <><Sparkles size={12} /> Generate Visual</>}
                </button>
            )}
          </div>
        )}
        <div className="absolute top-3 right-3 bg-white/90 backdrop-blur-sm px-3 py-1 rounded-full text-xs font-bold text-scriptoria-dark uppercase tracking-wider shadow-sm">
            {character.role}
        </div>
      </div>
      
      <div className="p-6 flex-1 flex flex-col">
        <h3 className="text-2xl font-serif font-bold text-gray-800 mb-1">{character.name}</h3>
        <p className="text-xs text-scriptoria-dark font-semibold uppercase tracking-widest mb-4">Character Profile</p>
        
        <div className="space-y-4 text-sm text-gray-600 flex-1">
          <div>
            <strong className="block text-gray-900 mb-1">Appearance</strong>
            <p>{character.physicalTraits}</p>
          </div>
          <div>
            <strong className="block text-gray-900 mb-1">Personality</strong>
            <p>{character.personality}</p>
          </div>
           <div>
            <strong className="block text-gray-900 mb-1">Inner Conflict</strong>
            <p>{character.motivation}</p>
          </div>
          <div className="pt-2 border-t border-gray-100 mt-2">
            <p className="italic text-gray-500">"{character.narrativePurpose}"</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CharacterCard;